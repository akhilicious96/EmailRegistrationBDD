package PageBean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailsPageFactory {

	WebDriver driver;

	public PaymentDetailsPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="txtFN")
	WebElement pfFirstName;
	
	@FindBy(name="debit")
	WebElement pfDebit;
	
	@FindBy(name="cvv")
	WebElement pfCvv;
	
	@FindBy(name="month")
	WebElement pfMonth;
	
	@FindBy(name="year")
	WebElement pfYear;
	
	@FindBy(id="btnPayment")
	WebElement pfBtnPayment;

	public WebElement getPfFirstName() {
		return pfFirstName;
	}

	public void setPfFirstName(String FirstName) {
		pfFirstName.sendKeys(FirstName);
	}

	public WebElement getPfDebit() {
		return pfDebit;
	}

	public void setPfDebit(String Debit) {
		pfDebit.sendKeys(Debit);
	}

	public WebElement getPfCvv() {
		return pfCvv;
	}

	public void setPfCvv(String Cvv) {
		pfCvv.sendKeys(Cvv);
	}

	public WebElement getPfMonth() {
		return pfMonth;
	}

	public void setPfMonth(String Month) {
		pfMonth.sendKeys(Month);
	}

	public WebElement getPfYear() {
		return pfYear;
	}

	public void setPfYear(String Year) {
		pfYear.sendKeys(Year);
	}

	public WebElement getPfBtnPayment() {
		return pfBtnPayment;
	}

	public void setPfBtnPayment() {
		pfBtnPayment.findElement(By.xpath("//*[@id='btnPayment']")).click();
	}
	
	
	
}
