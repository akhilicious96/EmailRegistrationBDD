package PaymentDetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

//---------------------------- Conference Registration And Booking --------------------------
		/*******************************************************************************************************
		 - Function Name	:	-
		 - Input Parameters	:	-
		 - Return Type		:	-
		 - Author			:	CAPGEMINI
		 - Creation Date	:	11/16/2018
		 - Description		:	RunTest class helps to run the cases written in step definition
		 ********************************************************************************************************/


@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"})
public class RunTestPaymentDetails {

}
