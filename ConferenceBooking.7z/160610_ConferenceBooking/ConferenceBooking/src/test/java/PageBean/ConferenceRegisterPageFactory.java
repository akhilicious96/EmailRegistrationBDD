package PageBean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegisterPageFactory {

	WebDriver driver;

	public ConferenceRegisterPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="txtFN")
	WebElement pfFirstName;
	
	@FindBy(name="txtLN")
	WebElement pfLastName;
	
	@FindBy(name="Email")
	WebElement pfEmail;
	
	@FindBy(name="Phone")
	WebElement pfPhone;
	
	@FindBy(name="size")
	WebElement pfSize;
	
	@FindBy(name="Address")
	WebElement pfAddress;
	
	@FindBy(name="Address2")
	WebElement pfAddress2;
	
	@FindBy(name="city")
	WebElement pfCity;
	
	@FindBy(name="state")
	WebElement pfState;
	
	@FindBy(name="memberStatus")
	WebElement pfMemberStatus;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[14]/td/a")
	WebElement pfNext;

	public WebElement getPfFirstName() {
		return pfFirstName;
	}

	public void setPfFirstName(String FirstName) {
		pfFirstName.sendKeys(FirstName);;
	}

	public WebElement getPfLastName() {
		return pfLastName;
	}

	public void setPfLastName(String LastName) {
		pfLastName.sendKeys(LastName);
	}

	public WebElement getPfEmail() {
		return pfEmail;
	}

	public void setPfEmail(String Email) {
		pfEmail.sendKeys(Email);
	}

	public WebElement getPfPhone() {
		return pfPhone;
	}

	public void setPfPhone(String Phone) {
		pfPhone.sendKeys(Phone);
	}

	public WebElement getPfSize() {
		return pfSize;
	}

	public void setPfSize(String Size) {
		Select sel = new Select(pfSize);
		sel.selectByValue(Size);
	}

	public WebElement getPfAddress() {
		return pfAddress;
	}

	public void setPfAddress(String Address) {
		pfAddress.sendKeys(Address);
	}

	public WebElement getPfAddress2() {
		return pfAddress2;
	}

	public void setPfAddress2(String Address2) {
		pfAddress2.sendKeys(Address2);
	}

	public WebElement getPfCity() {
		return pfCity;
	}

	public void setPfCity(String City) {
		Select sel = new Select(pfCity);
		sel.selectByValue(City);
	}

	public WebElement getPfState() {
		return pfState;
	}

	public void setPfState(String State) {
		Select sel = new Select(pfState);
		sel.selectByValue(State);
	}

	public WebElement getPfMemberStatus() {
		return pfMemberStatus;
	}

	public void setPfMemberStatus(String MemberStatus) {
		if(MemberStatus.equals("member")) {
			//pfMemberStatus.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input")).click();
			pfMemberStatus.click();
		}
		else if(MemberStatus.equals("non-member")) {
			//pfMemberStatus.findElement(By.xpath("html/body/form/table/tbody/tr[13]/td[2]/input")).click();
			pfMemberStatus.click();
		}
	}

	public WebElement getPfNext() {
		return pfNext;
	}

	public void setPfNext() {
		pfNext.click();
		
	}
	
	
	
	
	
	
	
	
}
