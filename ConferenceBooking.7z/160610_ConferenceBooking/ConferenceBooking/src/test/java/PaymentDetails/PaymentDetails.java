package PaymentDetails;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class PaymentDetails {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    //baseUrl = "http://change-this-to-the-site-you-are-testing/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testPaymentDetails() throws Exception {
    driver.get("file:///D:/BDD%20MPT%20case%20study/PaymentDetails.html");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the Card holder name", closeAlertAndGetItsText());
    driver.findElement(By.id("txtCardholderName")).clear();
    driver.findElement(By.id("txtCardholderName")).sendKeys("akhil");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the Debit card Number", closeAlertAndGetItsText());
    driver.findElement(By.id("txtDebit")).clear();
    driver.findElement(By.id("txtDebit")).sendKeys("456321789654");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the CVV", closeAlertAndGetItsText());
    driver.findElement(By.id("txtCvv")).clear();
    driver.findElement(By.id("txtCvv")).sendKeys("666");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill expiration month", closeAlertAndGetItsText());
    driver.findElement(By.id("txtMonth")).clear();
    driver.findElement(By.id("txtMonth")).sendKeys("11");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Please fill the expiration year", closeAlertAndGetItsText());
    driver.findElement(By.id("txtYear")).clear();
    driver.findElement(By.id("txtYear")).sendKeys("2100");
    driver.findElement(By.id("btnPayment")).click();
    assertEquals("Conference Room Booking successfully done!!!", closeAlertAndGetItsText());
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
