package ConferenceRegister;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import PageBean.ConferenceRegisterPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitionConferenceRegister {

	private WebDriver driver;
	private ConferenceRegisterPageFactory objcrpf;
	Alert  alert = null;
	String msg = "";
	
	//DesiredCapabilities dc = new DesiredCapabilities();
	
	
	//---------------------------- Conference Registration And Booking --------------------------
			/*******************************************************************************************************
			 - Function Name	:	Given
			 - Input Parameters	:	-
			 - Return Type		:	-
			 - Author			:	CAPGEMINI
			 - Creation Date	:	11/16/2018
			 - Description		:	Specified precondition for test cases
			 ********************************************************************************************************/
	
	
	@Given("^user is on the registration page$")
	public void user_is_on_the_registration_page() throws Throwable {
		//dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
	    driver = new FirefoxDriver();
	    objcrpf = new ConferenceRegisterPageFactory(driver);
	    driver.get("file:///D:/BDD%20MPT%20case%20study/ConferenceRegistartion.html");
	    
	}
	
	
	//---------------------------- Conference Registration And Booking --------------------------
	/*******************************************************************************************************
	 - Function Name	:	Then
	 - Input Parameters	:	-
	 - Return Type		:	-
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/16/2018
	 - Description		:	Specifies the outcome
	 ********************************************************************************************************/
	
	
	@Then("^verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		String title = driver.getTitle();
		if(title.equals("Conference Registartion"))
			System.out.println("Title correct");
		else
			System.out.println("Title Incorrect!");
		driver.close();
	}
	
	
	//---------------------------- Conference Registration And Booking --------------------------
	/*******************************************************************************************************
	 - Function Name	:	Given
	 - Input Parameters	:	-
	 - Return Type		:	-
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/16/2018
	 - Description		:	Specific action done by the user on the web page
	 ********************************************************************************************************/
	
	@When("^user does not enters firstname$")
	public void user_does_not_enters_firstname() throws Throwable {
	    objcrpf.setPfFirstName("");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	    
	}

	@Then("^pormpt to enter first name$")
	public void pormpt_to_enter_first_name() throws Throwable {
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the First Name");
		driver.close();
	    
	}

	@When("^user does not enter last name$")
	public void user_does_not_enter_last_name() throws Throwable {
	    objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	    
	}

	@Then("^prompt user to enter last name$")
	public void prompt_user_to_enter_last_name() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the Last Name");
		driver.close();
		
	}

	@When("^user does not enters email id$")
	public void user_does_not_enters_email_id() throws Throwable {
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	    
	}

	@Then("^prompt user to enter email id$")
	public void prompt_user_to_enter_email_id() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the Email");
		driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
	    
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("akhil");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	    
	}

	@Then("^prompt user to enter valid email id$")
	public void prompt_user_to_enter_valid_email_id() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please enter valid Email Id.");
		driver.close();
		
	}

	@When("^user does not enters contact$")
	public void user_does_not_enters_contact() throws Throwable {
	    
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("akhil@gmail.com");
	    objcrpf.setPfPhone("");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	}

	@Then("^prompt user to enter contact$")
	public void prompt_user_to_enter_contact() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the Contact No.");
		driver.close();
		
	}

	@When("^user enters invalid conatct$")
	public void user_enters_invalid_conatct() throws Throwable {
	    
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("akhil@gmail.com");
	    objcrpf.setPfPhone("123456");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	    
	}

	@Then("^prompt user to enter valid contact$")
	public void prompt_user_to_enter_valid_contact() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please enter valid Contact no.");
		driver.close();
	    
	}

	@When("^user does not select number of people$")
	public void user_does_not_select_number_of_people() throws Throwable {
	    
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("akhil@gmail.com");
	    objcrpf.setPfPhone("7021540643");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	    
	}

	@Then("^prompt user to select the number of people$")
	public void prompt_user_to_select_the_number_of_people() throws Throwable {
		
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the Number of people attending");
		driver.close();
	    
	}

	@When("^user does not enters building name and room number$")
	public void user_does_not_enters_building_name_and_room_number() throws Throwable {
	    
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("akhil@gmail.com");
	    objcrpf.setPfPhone("7021540643");
	    objcrpf.setPfSize("three");
	    objcrpf.setPfAddress("");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	}

	@Then("^prompt user to enter building name and room number$")
	public void prompt_user_to_enter_building_name_and_room_number() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the Building & Room No");
		driver.close();
		
	}

	@When("^user does not enter area name$")
	public void user_does_not_enter_area_name() throws Throwable {
	    
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("akhil@gmail.com");
	    objcrpf.setPfPhone("7021540643");
	    objcrpf.setPfSize("three");
	    objcrpf.setPfAddress("Capgemini");
	    objcrpf.setPfAddress2("");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	    
	}

	@Then("^pormpt user to enter area name$")
	public void pormpt_user_to_enter_area_name() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the Area name");
		driver.close();
	    
	}

	@When("^user does not select city$")
	public void user_does_not_select_city() throws Throwable {
	    
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("akhil@gmail.com");
	    objcrpf.setPfPhone("7021540643");
	    objcrpf.setPfSize("three");
	    objcrpf.setPfAddress("Capgemini");
	    objcrpf.setPfAddress2("Hinjawadi");
	    objcrpf.setPfCity("Select City");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	}

	@Then("^prompt user to select the city$")
	public void prompt_user_to_select_the_city() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please select city");
		driver.close();
		
	}

	@When("^user does not select the state$")
	public void user_does_not_select_the_state() throws Throwable {
		
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("akhil@gmail.com");
	    objcrpf.setPfPhone("7021540643");
	    objcrpf.setPfSize("three");
	    objcrpf.setPfAddress("Capgemini");
	    objcrpf.setPfAddress2("Hinjawadi");
	    objcrpf.setPfCity("Pune");
	    objcrpf.setPfState("Select State");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	    
	}

	@Then("^prompt user to select state$")
	public void prompt_user_to_select_state() throws Throwable {
	 
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please select state");
		driver.close();
	    
	}

	@When("^user does not select type of member$")
	public void user_does_not_select_type_of_member() throws Throwable {
	    
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("akhil@gmail.com");
	    objcrpf.setPfPhone("7021540643");
	    objcrpf.setPfSize("three");
	    objcrpf.setPfAddress("Capgemini");
	    objcrpf.setPfAddress2("Hinjawadi");
	    objcrpf.setPfCity("Pune");
	    objcrpf.setPfState("Maharashtra");
	    objcrpf.setPfMemberStatus("");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
		
	}

	@Then("^prompt user to select the type of member$")
	public void prompt_user_to_select_the_type_of_member() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please Select MemeberShip status");
		driver.close();
	}

	@When("^user clicks next link$")
	public void user_clicks_next_link() throws Throwable {
	    
		objcrpf.setPfFirstName("akhil");
	    objcrpf.setPfLastName("ahuja");
	    objcrpf.setPfEmail("akhil@gmail.com");
	    objcrpf.setPfPhone("7021540643");
	    objcrpf.setPfSize("three");
	    objcrpf.setPfAddress("Capgemini");
	    objcrpf.setPfAddress2("Hinjawadi");
	    objcrpf.setPfCity("Pune");
	    objcrpf.setPfState("Maharashtra");
	    objcrpf.setPfMemberStatus("member");
	    Thread.sleep(1000);
	    objcrpf.setPfNext();
	}

	@Then("^display the validation message$")
	public void display_the_validation_message() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Personal details are validated.");
		driver.close();
	    
	}

	@Then("^navigate to next page$")
	public void navigate_to_next_page() throws Throwable {
	    
	    driver.navigate().to("file:///D:/BDD%20MPT%20case%20study/PaymentDetails.html");
	    driver.close();
	}
	
}
