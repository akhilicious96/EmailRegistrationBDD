package PaymentDetails;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageBean.PaymentDetailsPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitionPaymentDetails {

	WebDriver driver;
	private PaymentDetailsPageFactory objpdpf;
	
	Alert  alert = null;
	String msg = "";
	
	
	//---------------------------- Conference Registration And Booking --------------------------
	/*******************************************************************************************************
	 - Function Name	:	Given
	 - Input Parameters	:	-
	 - Return Type		:	-
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/16/2018
	 - Description		:	Specified precondition for test cases
	 ********************************************************************************************************/

	
	@Given("^user is on the payment page$")
	public void user_is_on_the_payment_page() throws Throwable {
		driver = new FirefoxDriver();
		objpdpf = new PaymentDetailsPageFactory(driver);
		driver.get("file:///D:/BDD%20MPT%20case%20study/PaymentDetails.html");
	    
	}
	
	//---------------------------- Conference Registration And Booking --------------------------
		/*******************************************************************************************************
		 - Function Name	:	Then
		 - Input Parameters	:	-
		 - Return Type		:	-
		 - Author			:	CAPGEMINI
		 - Creation Date	:	11/16/2018
		 - Description		:	Specifies the outcome
		 ********************************************************************************************************/
	

	@Then("^verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		String title = driver.getTitle();
		if(title.equals("Payment Details"))
			System.out.println("Title correct");
		else
			System.out.println("Title Incorrect!");
		driver.close();
	    
	}
	
	
	//---------------------------- Conference Registration And Booking --------------------------
		/*******************************************************************************************************
		 - Function Name	:	Given
		 - Input Parameters	:	-
		 - Return Type		:	-
		 - Author			:	CAPGEMINI
		 - Creation Date	:	11/16/2018
		 - Description		:	Specific action done by the user on the web page
		 ********************************************************************************************************/

	@When("^user does not enters cardholder name$")
	public void user_does_not_enters_cardholder_name() throws Throwable {
	    objpdpf.setPfFirstName("");
	    Thread.sleep(1000);
	    objpdpf.setPfBtnPayment();
	    
	}

	@Then("^prompt user to enter the cardholder name$")
	public void prompt_user_to_enter_the_cardholder_name() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the Card holder name");
		driver.close();
		
	}

	@When("^user does not enters debit card number$")
	public void user_does_not_enters_debit_card_number() throws Throwable {
	    
		objpdpf.setPfFirstName("akhil");
		objpdpf.setPfDebit("");
	    Thread.sleep(1000);
	    objpdpf.setPfBtnPayment();
	    
	}

	@Then("^prompt user to enter debit card number$")
	public void prompt_user_to_enter_debit_card_number() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the Debit card Number");
		driver.close();
		
	}

	@When("^user does not enters debit card cvv$")
	public void user_does_not_enters_debit_card_cvv() throws Throwable {
	    
		objpdpf.setPfFirstName("akhil");
		objpdpf.setPfDebit("78945623");
		objpdpf.setPfCvv("");
	    Thread.sleep(1000);
	    objpdpf.setPfBtnPayment();
	    
	}

	@Then("^prompt user to enter debit card cvv$")
	public void prompt_user_to_enter_debit_card_cvv() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the CVV");
		driver.close();
	    
	}

	@When("^user does not enters card expiration month$")
	public void user_does_not_enters_card_expiration_month() throws Throwable {
	    
		objpdpf.setPfFirstName("akhil");
		objpdpf.setPfDebit("78945623");
		objpdpf.setPfCvv("666");
		objpdpf.setPfMonth("");
	    Thread.sleep(1000);
	    objpdpf.setPfBtnPayment();
		
	}

	@Then("^prompt user to enter card expiration month$")
	public void prompt_user_to_enter_card_expiration_month() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill expiration month");
		driver.close();
		
	}

	@When("^user does not enters card expiration year$")
	public void user_does_not_enters_card_expiration_year() throws Throwable {
		objpdpf.setPfFirstName("akhil");
		objpdpf.setPfDebit("78945623");
		objpdpf.setPfCvv("666");
		objpdpf.setPfMonth("11");
		objpdpf.setPfYear("");
	    Thread.sleep(1000);
	    objpdpf.setPfBtnPayment();
	    
	}

	@Then("^prompt user to enter card expiration year$")
	public void prompt_user_to_enter_card_expiration_year() throws Throwable {
	    
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Please fill the expiration year");
		driver.close();
	}

	@When("^user clicks the payment button$")
	public void user_clicks_the_payment_button() throws Throwable {
		objpdpf.setPfFirstName("akhil");
		objpdpf.setPfDebit("78945623");
		objpdpf.setPfCvv("666");
		objpdpf.setPfMonth("11");
		objpdpf.setPfYear("2022");
	    Thread.sleep(1000);
	    objpdpf.setPfBtnPayment();
	    
	}

	@Then("^display the successful message$")
	public void display_the_successful_message() throws Throwable {
		alert = driver.switchTo().alert();
		Thread.sleep(1000);
		msg = alert.getText();
		alert.accept();
		Thread.sleep(1000);
		assertEquals(msg,"Conference Room Booking successfully done!!!");
		driver.close();
	}
	
}
